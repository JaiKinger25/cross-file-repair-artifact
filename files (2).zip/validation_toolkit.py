"""Validation toolkit for the spreading-repair proxy (R14) and the AI-assistance markers.
Protocol: validation_protocol.md. Three tools in one file:

  sample   draw a stratified, blinded sample of R14 events for labelling
           python validation_toolkit.py sample events.csv --per-group 400 [--include-pre]
           (events.csv columns: repo, commit_hash, group (marked|control), period (post|pre), followup_hash)
  analyse  agreement, precision by group and the bias-corrected effect
           python validation_toolkit.py analyse --a1 labels_annotator1.csv --a2 labels_annotator2.csv [--adj labels_adjudicated.csv]
  markers  sample AI-marked commits by tool family, or analyse their labels
           python validation_toolkit.py markers sample marked_commits.csv --n 400
           python validation_toolkit.py markers analyse marker_sheet_labelled.csv

Labels for events: A = repair of a defect introduced by the original commit, in files outside it;
B = repair of a defect with another cause; C = planned continuation; D = refactoring, maintenance,
documentation or tooling; E = cannot be determined. Labels for markers: Y, N or U.
"""
import sys

SAMPLE = r'''import argparse, numpy as np, pandas as pd
ap=argparse.ArgumentParser(); ap.add_argument('events'); ap.add_argument('--per-group',type=int,default=400)
ap.add_argument('--seed',type=int,default=20261101); ap.add_argument('--include-pre',action='store_true')
a=ap.parse_args(); r=np.random.default_rng(a.seed)
ev=pd.read_csv(a.events)
periods=['post','pre'] if a.include_pre else ['post']
ev=ev[ev.period.isin(periods)]
parts=[]
for (g,per),df in ev.groupby(['group','period']):
    # proportional allocation across repositories, at least one event per repository where available
    share=df.repo.value_counts(normalize=True); alloc=np.maximum(1,np.round(share*a.per_group)).astype(int)
    for repo,k in alloc.items():
        pool=df[df.repo==repo]; parts.append(pool.sample(n=min(k,len(pool)),random_state=int(r.integers(1e9))))
s=pd.concat(parts).sample(frac=1,random_state=int(r.integers(1e9))).reset_index(drop=True)
s['item_id']=[f'E{i:05d}' for i in range(len(s))]
gh=lambda repo,h:f'https://github.com/{repo}/commit/{h}'
sheet=pd.DataFrame({'item_id':s.item_id,'original_commit':[gh(x,y) for x,y in zip(s.repo,s.commit_hash)],
    'followup_commit':[gh(x,y) for x,y in zip(s.repo,s.followup_hash)],'label':'', 'notes':''})
sheet.to_csv('annotation_sheet.csv',index=False); s[['item_id','repo','group','period']].to_csv('annotation_key.csv',index=False)
print(f'{len(s)} items written; per group/period:'); print(s.groupby(['group','period']).size())
print('Labels: A = repair of a defect introduced by the original commit, in files outside it; B = repair of a defect with another cause;')
print('        C = planned continuation; D = refactoring, maintenance, documentation or tooling; E = cannot be determined.')
'''
ANALYSE = r'''import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import argparse, numpy as np, pandas as pd
from scipy import stats
ap=argparse.ArgumentParser(); ap.add_argument('--a1',required=True); ap.add_argument('--a2',required=True); ap.add_argument('--adj')
ap.add_argument('--key',default='annotation_key.csv'); ap.add_argument('--table',default=DATA); ap.add_argument('--seed',type=int,default=1)
a=ap.parse_args(); r=np.random.default_rng(a.seed)
key=pd.read_csv(a.key); l1=pd.read_csv(a.a1).rename(columns={'label':'l1'}); l2=pd.read_csv(a.a2).rename(columns={'label':'l2'})
df=key.merge(l1,on='item_id').merge(l2,on='item_id')
cats=list('ABCDE')
def kappa(x,y):
    po=(x==y).mean(); pe=sum((x==c).mean()*(y==c).mean() for c in cats); return (po-pe)/(1-pe), po
k,po=kappa(df.l1.values,df.l2.values)
kb=[kappa(*df.sample(frac=1,replace=True,random_state=int(r.integers(1e9)))[['l1','l2']].values.T)[0] for _ in range(2000)]
df['label']=np.where(df.l1==df.l2,df.l1,None)
if a.adj:
    adj=pd.read_csv(a.adj).set_index('item_id').label; m=df.label.isna(); df.loc[m,'label']=df.loc[m,'item_id'].map(adj)
unres=df.label.isna().sum(); df=df[df.label.notna()]
def wilson(x,n,z=1.96):
    p=x/n; c=(p+z*z/(2*n))/(1+z*z/n); h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n); return p,c-h,c+h
post=df[df.period=='post']; res={}
for g in ['marked','control']:
    s=post[post.group==g]; res[g]=(int((s.label=='A').sum()),len(s))
pm,pmL,pmU=wilson(*res['marked']); pc,pcL,pcU=wilson(*res['control'])
# Newcombe hybrid score interval for the difference
d=pm-pc; dl=d-np.sqrt((pm-pmL)**2+(pcU-pc)**2); du=d+np.sqrt((pmU-pm)**2+(pc-pcL)**2)
# bias-corrected effect: theta_A = sum_r w_r (marked_r * pM_r - control_r * pC_r), with precision estimated pooled
# (repository-stratified precision is used when every repository has >= 10 labelled events per group)
t=pd.read_csv(a.table); w=t.n/t.n.sum()
B=5000; out=np.empty(B)
lab={g:(post[post.group==g].label=='A').values.astype(float) for g in res}
for b in range(B):
    idx=r.integers(0,len(t),len(t)); ww=t.n.values[idx]/t.n.values[idx].sum()
    qm=r.choice(lab['marked'],len(lab['marked'])).mean(); qc=r.choice(lab['control'],len(lab['control'])).mean()
    out[b]=(ww*(t.marked.values[idx]*qm-t.control.values[idx]*qc)).sum()
thA=(w*(t.marked*pm-t.control*pc)).sum(); lo,hi=np.percentile(out,[2.5,97.5])
print(f'Items labelled: {len(df)+unres}; unresolved: {unres}')
print(f'Cohen kappa = {k:.2f} (95% CI {np.percentile(kb,2.5):.2f} to {np.percentile(kb,97.5):.2f}); raw agreement {po:.1%}')
print(f'Precision (class A), marked:  {pm:.3f} ({pmL:.3f} to {pmU:.3f}), n = {res["marked"][1]}')
print(f'Precision (class A), control: {pc:.3f} ({pcL:.3f} to {pcU:.3f}), n = {res["control"][1]}')
print(f'Difference (marked - control): {100*d:+.1f} points ({100*dl:+.1f} to {100*du:+.1f})')
print(f'Bias-corrected difference in genuine spreading repair: {thA:+.2f} pp (95% CI {lo:+.2f} to {hi:+.2f})')
null_gap=pc*(1-48.0/50.8)
verdict=('excludes' if (dl>-null_gap) else 'does not exclude')
print(f'Precision gap that would erase the effect: {100*null_gap:.1f} points; the interval {verdict} a gap of that size.')
print('\nPaste-ready paragraph:\n')
print(f'Two annotators blind to marker status labelled {len(df)+unres} sampled spreading-repair events (Cohen\'s kappa = {k:.2f}, '
      f'95% CI {np.percentile(kb,2.5):.2f} to {np.percentile(kb,97.5):.2f}). The share of events that repaired a defect introduced by the original '
      f'commit in files outside it was {pm:.2f} for marked and {pc:.2f} for control commits (difference {100*d:+.1f} points, 95% CI {100*dl:+.1f} to {100*du:+.1f}). '
      f'Restricting the outcome to these validated repairs gives a difference of {thA:+.1f} percentage points (95% CI {lo:+.1f} to {hi:+.1f}).')
'''
MARKERS = r'''import argparse, numpy as np, pandas as pd
def wilson(x,n,z=1.96):
    if n==0: return float('nan'),float('nan'),float('nan')
    p=x/n; c=(p+z*z/(2*n))/(1+z*z/n); h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n); return p,c-h,c+h
ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
s1=sub.add_parser('sample'); s1.add_argument('csv'); s1.add_argument('--n',type=int,default=400); s1.add_argument('--seed',type=int,default=20261101)
s2=sub.add_parser('analyse'); s2.add_argument('csv')
a=ap.parse_args()
if a.cmd=='sample':
    d=pd.read_csv(a.csv); r=np.random.default_rng(a.seed)
    share=d.family.value_counts(normalize=True); alloc=np.maximum(20,np.round(share*a.n)).astype(int)   # at least 20 per family
    parts=[d[d.family==f].sample(n=min(k,(d.family==f).sum()),random_state=int(r.integers(1e9))) for f,k in alloc.items()]
    s=pd.concat(parts).sample(frac=1,random_state=int(r.integers(1e9))).reset_index(drop=True)
    s['commit_url']=[f'https://github.com/{x}/commit/{y}' for x,y in zip(s.repo,s.commit_hash)]; s['label']=''; s['notes']=''
    s[['commit_url','family','label','notes']].to_csv('marker_sheet.csv',index=False); print(len(s),'commits written to marker_sheet.csv'); print(s.family.value_counts())
else:
    d=pd.read_csv(a.csv); d=d[d.label.isin(['Y','N'])]
    p,l,u=wilson((d.label=='Y').sum(),len(d)); print(f'Overall marker precision: {p:.3f} (95% CI {l:.3f} to {u:.3f}), n = {len(d)}')
    for f,g in d.groupby('family'):
        p,l,u=wilson((g.label=='Y').sum(),len(g)); print(f'  {f:12s} {p:.3f} ({l:.3f} to {u:.3f}), n = {len(g)}')
'''

def _run(code, argv):
    sys.argv = [sys.argv[0]] + argv
    exec(compile(code, "<validation_toolkit>", "exec"), {"__name__": "__main__"})

def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("sample", "analyse", "markers"):
        print(__doc__); sys.exit(1)
    cmd, rest = sys.argv[1], sys.argv[2:]
    _run({"sample": SAMPLE, "analyse": ANALYSE, "markers": MARKERS}[cmd], rest)

if __name__ == "__main__":
    main()
