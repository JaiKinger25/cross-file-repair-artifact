# Data dictionary

## table_d1.csv (repository-level data, 45 rows)
| Column | Type | Meaning |
|---|---|---|
| repo | text | GitHub repository (owner/name) |
| n | integer | Number of matched sets: AI-marked commits with at least one matched control |
| marked | percent | Share of AI-marked commits followed by a spreading-repair event (R14) |
| control | percent | Mean R14 rate of the matched control commits (averaged within each set, then over sets) |
| diff | percentage points | marked minus control |
| ai_repo | 0/1 | 1 = AI-tool repository (an LLM or agent tool, LLM framework or SDK, or model runtime); 0 = general-purpose. Assigned after the main analysis (post hoc) |

## repositories.csv (77 rows)
| Column | Meaning |
|---|---|
| repository | GitHub repository chosen in advance |
| in_analysis | yes, or the reason it was not analysed (fewer than 20 matched sets or no eligible AI-marked commits) |
| matched_sets, R14_marked_pct, R14_control_pct, difference_pp, type | As in table_d1.csv, for analysed repositories |

## sensitivity_results.csv
| Column | Meaning |
|---|---|
| analysis | Analysis name (main, S1-S7, post hoc checks, secondary outcomes) |
| status | pre-specified or post hoc |
| sample | Matched sets and repositories, where they differ from the main analysis |
| marked_pct, control_pct | Outcome rates (%); "not available" where not recorded |
| difference_pp, ci_low, ci_high | Difference in percentage points and 95% cluster-bootstrap interval |

## simulation_summary.csv (Table 3 and Online Appendix Table A5)
| Column | Meaning |
|---|---|
| scenario | Code name S0-S5 (paper: Sim0-Sim5) with a short description |
| volatility_sd | SD of the set-level volatility effect (1 = main; 0.5 and 2 = sensitivity) |
| replicates | Number of simulated data sets |
| cov_percentile, cov_bca, cov_cr1, cov_wild, cov_did, cov_hksj_vs_mu | Coverage (%) of nominal 95% intervals |
| rej_percentile, rej_cr1, rej_wild, rej_hksj | Rejection rate (%) of H0: effect = 0 at alpha = 0.05 |
| bias_matched, bias_did | Mean estimate minus true effect (pp) |
| mean_placebo | Mean placebo estimate (pp) |
| rmse_matched, rmse_did | Root mean squared error (pp) |

## noise_curve_summary.csv (Fig. 2)
| Column | Meaning |
|---|---|
| dq_points | Gap in spurious-event rate between marked and control commits (points) |
| gap | "both periods" (constant over time) or "post only" (after the commit only) |
| bias_closed_form | Bias predicted by Eq. (3) |
| bias_matched_sim, bias_did_sim | Simulated bias of the matched and DiD estimators (pp) |
| fpr_matched_wild_pct, fpr_did_wild_pct | False-positive rate (%) with the wild cluster bootstrap |

## prespecification_record.csv
| Column | Meaning |
|---|---|
| analysis | Analysis reported in the paper |
| status | pre-specified, pre-specified sensitivity, pre-specified (exploratory) or post hoc |
| where_reported | Section, table or figure |

## Outcome definitions (Section 3.1)
| Outcome | Definition |
|---|---|
| R14 (primary) | Within 14 days, a fix-like commit by a non-bot author touches at least one file the original commit changed and at least one it did not |
| Placebo | R14 applied to the 14 days before the commit |
| F14 | Within 14 days, a fix-like commit touches at least one shared file |
| RW14 | Within 14 days, any later commit touches at least one shared file |
| REV30 | The commit is reverted within 30 days |
| W | Repair width: largest number of outside files touched by a fix-like follow-up |
| Fix-like | Subject contains fix, bug, hotfix, regression, revert, broke or crash as a whole word |

## Files produced by pipeline.py
| File | Meaning |
|---|---|
| commits.jsonl | One commit per line: repo, h (hash), an/ae (author name/e-mail), cn/ce (committer), date, msg, files |
| matched_sets.csv | One matched set per row: repo, marked hash, family, control hashes, number of controls, and each outcome for the marked commit and the mean over its controls |
| table_d1_rebuilt.csv | Repository-level table in the format of table_d1.csv |
