"""Main analysis (Table 1): spreading-repair rates, differences, cluster-bootstrap CIs and DiD.

REIMPLEMENTATION NOTICE
This script reimplements the primary analysis described in Sections 3.2-3.3 of the paper.
It is not the original script that produced Table 1. It reads the matched sets written by
pipeline.py (matched_sets.csv) and computes, for each outcome, the marked rate, the control
rate, the matched difference with a percentile cluster bootstrap over repositories
(5,000 resamples, seed 20261020), the rate ratio, and the difference-in-differences (DiD)
estimate (post-period difference minus pre-period placebo difference).

The repository-level re-analysis that produced Table 2, the fragility indices and the
bias analysis is in reanalysis.py, fragility_exact.py and bias_analysis.py.

Usage
  python analysis.py --sets matched_sets.csv --out table1_results.csv
Input columns (from pipeline.py): repo, R14_marked, R14_control, F14_marked, F14_control,
  RW14_marked, RW14_control, REV30_marked, REV30_control, W_marked, W_control,
  PLAC_marked, PLAC_control
"""
import argparse
import numpy as np
import pandas as pd

SEED = 20261020
B = 5000
MIN_SETS = 20


def repo_sums(d, cols):
    """Per-repository sums of the given columns and the number of matched sets."""
    g = d.groupby("repo")[cols].sum()
    g["n"] = d.groupby("repo").size()
    return g


def bootstrap(g, stat, rng, b=B):
    """Percentile cluster bootstrap: resample repositories with replacement."""
    idx = rng.integers(0, len(g), (b, len(g)))
    vals = g.to_numpy()
    cols = list(g.columns)
    out = np.empty(b)
    for i in range(b):
        s = vals[idx[i]].sum(0)
        out[i] = stat(dict(zip(cols, s)))
    return np.nanpercentile(out, [2.5, 97.5])


def analyse(d, outcome, rng):
    m, c = f"{outcome}_marked", f"{outcome}_control"
    g = repo_sums(d, [m, c])
    scale = 1.0 if outcome == "W" else 100.0
    diff = lambda s: scale * (s[m] - s[c]) / s["n"]
    ratio = lambda s: s[m] / s[c] if s[c] > 0 else np.nan
    tot = dict(g.sum())
    lo, hi = bootstrap(g, diff, rng)
    rlo, rhi = bootstrap(g, ratio, rng)
    return dict(outcome=outcome, sets=int(tot["n"]), repositories=len(g),
                marked=scale * tot[m] / tot["n"], control=scale * tot[c] / tot["n"],
                difference=diff(tot), ci_low=lo, ci_high=hi,
                ratio=ratio(tot), ratio_low=rlo, ratio_high=rhi)


def analyse_did(d, rng):
    d = d.assign(post=d.R14_marked - d.R14_control, pre=d.PLAC_marked - d.PLAC_control)
    g = repo_sums(d, ["post", "pre"])
    did = lambda s: 100 * (s["post"] - s["pre"]) / s["n"]
    tot = dict(g.sum())
    lo, hi = bootstrap(g, did, rng)
    return dict(outcome="DiD (R14 minus placebo)", sets=int(tot["n"]), repositories=len(g),
                marked=np.nan, control=np.nan, difference=did(tot), ci_low=lo, ci_high=hi,
                ratio=np.nan, ratio_low=np.nan, ratio_high=np.nan)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sets", default="matched_sets.csv")
    ap.add_argument("--out", default="table1_results.csv")
    a = ap.parse_args()
    d = pd.read_csv(a.sets)
    keep = d.repo.value_counts()
    d = d[d.repo.isin(keep[keep >= MIN_SETS].index)]          # repositories with >= 20 matched sets
    rng = np.random.default_rng(SEED)
    rows = [analyse(d, o, rng) for o in ["R14", "F14", "RW14", "REV30", "W"]]
    rows.append(analyse(d, "PLAC", rng) | {"outcome": "Placebo R14, 14 days before"})
    rows.append(analyse_did(d, rng))
    out = pd.DataFrame(rows)
    out.to_csv(a.out, index=False, float_format="%.3f")
    pd.set_option("display.width", 160)
    print(out[["outcome", "sets", "repositories", "marked", "control", "difference", "ci_low", "ci_high", "ratio"]]
          .round(2).to_string(index=False))


if __name__ == "__main__":
    main()
