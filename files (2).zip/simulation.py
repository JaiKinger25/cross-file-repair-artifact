"""Simulation study with known ground truth, calibrated to Table D1.
Generates commit-level matched sets for 45 repositories and evaluates estimators and
interval methods under (i) no effect, (ii) a true effect, (iii) time-invariant confounding by
file volatility, (iv) proxy label noise with equal or differential spurious-event rates."""
import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import numpy as np, pandas as pd, json, sys, zlib
from scipy import stats
d=pd.read_csv(DATA); n=d.n.values; G=len(d); base=np.log(d.control.values/(100-d.control.values))
rid=np.repeat(np.arange(G),n); S=n.sum(); w=n/n.sum()
expit=lambda x:1/(1+np.exp(-x)); tq=stats.t.ppf(.975,G-1)
def sim_rep(r,mu,tau,gamma,qC,qM,sd_u=1.0):
    m=r.choice([5,4,3,2,1],S,p=[.85,.10,.03,.01,.01])                 # controls per set
    u=r.normal(0,sd_u,S)                                                  # set-level file volatility (shared by matching)
    D=r.normal(mu,tau,G)/100                                             # repository effects (risk-difference scale)
    out={}
    for per in ('pre','post'):
        pc=expit(base[rid]+u); pm0=expit(base[rid]+u+gamma)
        pm=np.clip(pm0+(D[rid] if per=='post' else 0),0,1)
        ym=r.random(S)<pm; yc=r.binomial(m,pc)/m
        if qC>0:   # proxy noise: spurious fix-like cross-file events
            ym=ym|(r.random(S)<qM)
            yc_true=r.binomial(m,pc); yc=(yc_true+r.binomial(m-yc_true,qC))/m
        out[per]=ym.astype(float)-yc

    dr_post=np.bincount(rid,out['post'])/n*100; dr_pre=np.bincount(rid,out['pre'])/n*100
    return dr_post,dr_pre,mu,D.mean()*100
def intervals(dr,rng,B=999):
    th=(w*dr).sum(); idx=rng.integers(0,G,(B,G)); bt=(n[idx]*dr[idx]).sum(1)/n[idx].sum(1)
    pct=np.percentile(bt,[2.5,97.5])
    jk=np.array([np.delete(n*dr,i).sum()/np.delete(n,i).sum() for i in range(G)])
    z0=stats.norm.ppf(np.clip((bt<th).mean(),1e-4,1-1e-4)); a=((jk.mean()-jk)**3).sum()/(6*(((jk.mean()-jk)**2).sum())**1.5+1e-12)
    zz=stats.norm.ppf([.025,.975]); q=stats.norm.cdf(z0+(z0+zz)/(1-a*(z0+zz))); bca=np.percentile(bt,100*q)
    se=np.sqrt((G/(G-1))*((n*(dr-th))**2).sum())/n.sum(); cr=[th-tq*se,th+tq*se]
    return th,pct,bca,cr,se
def wild_reject(dr,h0,rng,B=499):
    th=(w*dr).sum(); se=np.sqrt((G/(G-1))*((n*(dr-th))**2).sum())/n.sum(); t0=(th-h0)/se
    e=dr-h0; s=rng.choice([-1,1],(B,G)); ys=h0+s*e; tb=(n*ys).sum(1)/n.sum(); u=ys-tb[:,None]
    sb=np.sqrt((G/(G-1))*((n*u)**2).sum(1))/n.sum(); return ((np.abs((tb-h0)/sb)>=abs(t0)).mean())<0.05
def hksj(dr,v):
    wi=1/v; fe=(wi*dr).sum()/wi.sum(); Q=(wi*(dr-fe)**2).sum(); C=wi.sum()-(wi**2).sum()/wi.sum()
    t2=max(0,(Q-(G-1))/C); ws=1/(v+t2); re=(ws*dr).sum()/ws.sum(); q=(ws*(dr-re)**2).sum()/((G-1)*ws.sum())
    return re,[re-tq*np.sqrt(q),re+tq*np.sqrt(q)]
pc_=d.control.values/100; pm_=d.marked.values/100; v=(pm_*(1-pm_)/n+pc_*(1-pc_)/(4.8*n))*1e4
SCEN={'S0 no effect':dict(mu=0,tau=6.2,gamma=0,qC=0,qM=0),
      'S1 true effect 2.8':dict(mu=2.8,tau=6.2,gamma=0,qC=0,qM=0),
      'S2 confounding, no effect':dict(mu=0,tau=6.2,gamma=0.045,qC=0,qM=0),
      'S3 confounding + effect 1.9':dict(mu=1.9,tau=6.2,gamma=0.045,qC=0,qM=0),
      'S4 equal proxy noise, no effect':dict(mu=0,tau=6.2,gamma=0,qC=0.30,qM=0.30),
      'S5 differential proxy noise, no effect':dict(mu=0,tau=6.2,gamma=0,qC=0.30,qM=0.33)}
if __name__=='__main__':
    R=int(sys.argv[1]); which=int(sys.argv[2]); SDU=float(sys.argv[3]) if len(sys.argv)>3 else 1.0
    res={}
    for name,p in [list(SCEN.items())[which]]:
        r=np.random.default_rng(zlib.crc32(name.encode())+1000*int(10*SDU)); acc={k:[] for k in ['th','did','plac','cov_pct','cov_bca','cov_cr','cov_wild','rej_pct','rej_cr','rej_wild','cov_hksj','rej_hksj','cov_did','truth','mu']}
        for it in range(R):
            post,pre,truth,mu=sim_rep(r,**p,sd_u=SDU)
            th,pct,bca,cr,se=intervals(post,r); did=post-pre; thd,pd_,_,crd,_=intervals(did,r,B=199)
            re,hk=hksj(post,v)
            acc['th'].append(th); acc['did'].append(thd); acc['plac'].append((w*pre).sum()); acc['truth'].append(truth); acc['mu'].append(mu)
            acc['cov_pct'].append(pct[0]<=truth<=pct[1]); acc['cov_bca'].append(bca[0]<=truth<=bca[1]); acc['cov_cr'].append(cr[0]<=truth<=cr[1])
            acc['cov_wild'].append(not wild_reject(post,truth,r)); acc['cov_did'].append(crd[0]<=truth<=crd[1])
            acc['rej_pct'].append(pct[0]>0 or pct[1]<0); acc['rej_cr'].append(cr[0]>0 or cr[1]<0); acc['rej_wild'].append(wild_reject(post,0.0,r))
            acc['cov_hksj'].append(hk[0]<=p['mu']<=hk[1]); acc['rej_hksj'].append(hk[0]>0 or hk[1]<0)
        s={k:float(np.mean(v_)) for k,v_ in acc.items()}
        s['bias_th']=float(np.mean(np.array(acc['th'])-np.array(acc['truth']))); s['bias_did']=float(np.mean(np.array(acc['did'])-np.array(acc['truth'])))
        s['rmse_th']=float(np.sqrt(np.mean((np.array(acc['th'])-np.array(acc['truth']))**2))); s['rmse_did']=float(np.sqrt(np.mean((np.array(acc['did'])-np.array(acc['truth']))**2)))
        s['sd_th']=float(np.std(acc['th'])); res[name]=s
        print(name,{k:round(x,3) for k,x in s.items()},flush=True)
    json.dump(res,open(f'sim_{which}_{R}_sdu{SDU}.json','w'),indent=1)
