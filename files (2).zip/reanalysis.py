"""Repository-level re-analysis of the primary outcome (R14) from Table D1.
All analyses use only the published repository-level table."""
import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import numpy as np, pandas as pd, json
from scipy import stats
rng = np.random.default_rng(20261020)
d = pd.read_csv(DATA)
n = d.n.values.astype(float); y = d['diff'].values; pm = d.marked.values/100; pc = d.control.values/100
G = len(d); R = {}
w = n/n.sum()
theta = (w*y).sum(); R['theta']=theta

# 1. cluster bootstrap (percentile), 20000
B=20000; idx = rng.integers(0,G,(B,G))
bt = (n[idx]*y[idx]).sum(1)/n[idx].sum(1)
R['boot_pct']=np.percentile(bt,[2.5,97.5]).tolist()
# BCa
jk = np.array([np.delete(n*y,i).sum()/np.delete(n,i).sum() for i in range(G)])
z0 = stats.norm.ppf((bt<theta).mean()); a = ((jk.mean()-jk)**3).sum()/(6*(((jk.mean()-jk)**2).sum())**1.5)
def bca(q):
    z=stats.norm.ppf(q); return stats.norm.cdf(z0+(z0+z)/(1-a*(z0+z)))
R['boot_bca']=np.percentile(bt,[100*bca(.025),100*bca(.975)]).tolist()
# 2. cluster-robust (CR1) t interval for the weighted mean
u = y-theta
se_cr = np.sqrt((G/(G-1))*((n*u)**2).sum())/n.sum()
tq = stats.t.ppf(.975,G-1)
R['cr_t']=[theta-tq*se_cr, theta+tq*se_cr, se_cr]
# 3. wild cluster bootstrap with null imposed (Rademacher) -> p-value; and CI by test inversion
def wild_p(h0, B=9999, seed=1):
    r=np.random.default_rng(seed); e=y-h0  # residuals under null mean=h0 (weighted)
    t_obs=(theta-h0)/se_cr
    s=r.choice([-1,1],(B,G)); ys=h0+s*e
    th=(n*ys).sum(1)/n.sum(); uu=ys-th[:,None]
    se=np.sqrt((G/(G-1))*((n*uu)**2).sum(1))/n.sum()
    t=(th-h0)/se
    return ( (np.abs(t)>=abs(t_obs)).sum()+1)/(B+1)
R['wild_p0']=wild_p(0.0)
grid=np.round(np.arange(-1.0,7.0,0.05),2)
ps=np.array([wild_p(h,B=4999,seed=2) for h in grid])
acc=grid[ps>0.05]; R['wild_ci']=[acc.min(),acc.max()]
# 4. exact cluster sign-flip randomisation test of weighted mean (Monte Carlo, 100k)
s=rng.choice([-1,1],(100000,G)); flip=(s*n*y).sum(1)/n.sum()
R['signflip_p']=((np.abs(flip)>=abs(theta)).sum()+1)/(100001)
# unweighted
R['unw_mean']=y.mean(); R['unw_t']=stats.ttest_1samp(y,0).pvalue
R['wilcoxon_p']=stats.wilcoxon(y).pvalue; R['sign_pos']=int((y>0).sum()); R['sign_neg']=int((y<0).sum())
R['median']=float(np.median(y)); R['sd']=float(y.std(ddof=1))
# 5. approximate per-repo variance and DerSimonian-Laird random-effects
k=4.8
v = (pm*(1-pm)/n + pc*(1-pc)/(k*n))*1e4   # pp^2
wi=1/v; fe=(wi*y).sum()/wi.sum(); Q=(wi*(y-fe)**2).sum(); df=G-1
C=wi.sum()-(wi**2).sum()/wi.sum(); tau2=max(0,(Q-df)/C)
ws=1/(v+tau2); re=(ws*y).sum()/ws.sum(); se_re=np.sqrt(1/ws.sum())
I2=max(0,(Q-df)/Q)
R['DL']=dict(fe=fe,Q=Q,I2=I2,tau2=tau2,tau=np.sqrt(tau2),re=re,ci=[re-1.96*se_re,re+1.96*se_re])
# Hartung-Knapp-Sidik-Jonkman
q_hk=(ws*(y-re)**2).sum()/(df*ws.sum()); se_hk=np.sqrt(q_hk)
R['HKSJ_ci']=[re-tq*se_hk, re+tq*se_hk]
# 95% prediction interval (Higgins et al. 2009), t with G-2 df
tp=stats.t.ppf(.975,G-2); R['PI']=[re-tp*np.sqrt(tau2+se_re**2), re+tp*np.sqrt(tau2+se_re**2)]
# 6. meta-regressions (weighted least squares with RE weights, CR SE)
def wls(X, yv, wv):
    X=np.column_stack([np.ones(len(yv)),X]); W=np.diag(wv)
    beta=np.linalg.solve(X.T@W@X, X.T@W@yv); res=yv-X@beta
    bread=np.linalg.inv(X.T@W@X); meat=X.T@np.diag((wv*res)**2)@X
    V=bread@meat@bread*G/(G-X.shape[1]); se=np.sqrt(np.diag(V))
    p=2*stats.t.sf(np.abs(beta/se),G-X.shape[1]); return beta,se,p
R['mr_control']=[x.tolist() for x in wls(d.control.values-50, y, n)]
R['mr_airepo']=[x.tolist() for x in wls(d.ai_repo.values, y, n)]
R['mr_logn']=[x.tolist() for x in wls(np.log(n)-np.log(n).mean(), y, n)]
R['mr_marked']=[x.tolist() for x in wls(d.marked.values-50, y, n)]
# subgroup estimates
for g,lab in [(1,'ai'),(0,'gen')]:
    m=d.ai_repo.values==g; nn=n[m]; yy=y[m]; th=(nn*yy).sum()/nn.sum()
    ii=rng.integers(0,m.sum(),(20000,m.sum())); bb=(nn[ii]*yy[ii]).sum(1)/nn[ii].sum(1)
    R['sub_'+lab]=dict(k=int(m.sum()),sets=int(nn.sum()),theta=th,ci=np.percentile(bb,[2.5,97.5]).tolist(),pos=int((yy>0).sum()))
# 7. power / minimum detectable effect
se_b=(R['boot_pct'][1]-R['boot_pct'][0])/(2*1.96)
R['se_boot']=se_b; R['MDE80']=(1.96+0.8416)*se_b; R['MDE90']=(1.96+1.2816)*se_b
R['power_at_theta']=float(stats.norm.cdf(theta/se_b-1.96)+stats.norm.cdf(-theta/se_b-1.96))
json.dump(R,open('reanalysis.json','w'),indent=1,default=float)
for kk,vv in R.items(): print(kk, vv)
