import json,glob,numpy as np,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':7.5,'axes.linewidth':0.6})
import pandas as pd
_c=pd.read_csv('noise_curve_summary.csv'); _b=_c[_c.gap=='both periods'].sort_values('dq_points'); _p=_c[_c.gap=='post only'].iloc[0]
R=[{'dq':r.dq_points,'bias':r.bias_matched_sim,'bias_did':r.bias_did_sim,'fpr_wild':r.fpr_matched_wild_pct/100,'fpr_did_wild':r.fpr_did_wild_pct/100} for r in _b.itertuples()]
P={'bias_did':_p.bias_did_sim,'fpr_did_wild':_p.fpr_did_wild_pct/100}
q=np.array([r['dq'] for r in R]); fig,ax=plt.subplots(1,2,figsize=(4.6,1.95))
x=np.linspace(0,5,50); ax[0].plot(x,x*(1-0.480),'-',color='black',lw=0.9,label='Closed form (3)')
ax[0].plot(q,[r['bias'] for r in R],'s',color='#1f4e79',ms=3.5,label='Matched, simulated')
ax[0].plot(q,[r['bias_did'] for r in R],'o',mfc='none',mec='#555555',ms=3.5,label='DiD, gap in both periods')
ax[0].plot([3],[P['bias_did']],'x',color='#b22222',ms=5,mew=1.2,label='DiD, gap after commit only')
ax[0].set_xlabel('Spurious-event gap Δq (points)'); ax[0].set_ylabel('Bias (pp)'); ax[0].legend(fontsize=5.4,frameon=False,loc='upper left')
ax[1].plot(q,[100*r['fpr_wild'] for r in R],'s-',color='#1f4e79',ms=3.2,lw=0.8,label='Matched')
ax[1].plot(q,[100*r['fpr_did_wild'] for r in R],'o-',mfc='none',color='#555555',ms=3.2,lw=0.8,label='DiD')
ax[1].plot([3],[100*P['fpr_did_wild']],'x',color='#b22222',ms=5,mew=1.2,label='DiD, gap after commit only')
ax[1].axhline(5,color='grey',ls=':',lw=0.7); ax[1].set_xlabel('Spurious-event gap Δq (points)'); ax[1].set_ylabel('False-positive rate (%)')
ax[1].legend(fontsize=5.4,frameon=False,loc='upper left')
for a in ax: a.spines[['top','right']].set_visible(False)
fig.tight_layout(w_pad=1.0); fig.savefig('fig_noise.png',dpi=300); print('ok')
