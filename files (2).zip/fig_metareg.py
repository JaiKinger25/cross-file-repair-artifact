"""Draws Fig. 1 (repository differences against control rate, weighted meta-regression line)."""
import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
plt.rcParams.update({'font.family':'serif','font.size':7.5})
d=pd.read_csv(DATA); n=d.n.values; X=np.column_stack([np.ones(len(d)),d.control-50])
beta=np.linalg.solve(X.T@(X*n[:,None]),X.T@(n*d['diff'].values))
fig,ax=plt.subplots(figsize=(3.45,2.3)); c=np.where(d.ai_repo==1,'#1f4e79','#b0b0b0')
ax.scatter(d.control,d['diff'],s=n/6,c=c,edgecolor='black',linewidths=0.3,alpha=0.85)
xs=np.linspace(10,80,50); ax.plot(xs,beta[0]+beta[1]*(xs-50),color='black',lw=0.8); ax.axhline(0,color='grey',lw=0.6,ls='--')
ax.set_xlabel('Control rate of R14 in repository (%)'); ax.set_ylabel('Difference (pp)')
ax.legend(handles=[Line2D([],[],marker='o',ls='',mfc='#1f4e79',mec='k',label='AI-tool repository'),Line2D([],[],marker='o',ls='',mfc='#b0b0b0',mec='k',label='General-purpose')],fontsize=6,frameon=False,loc='lower left')
ax.spines[['top','right']].set_visible(False); fig.tight_layout(); fig.savefig('fig2_metareg.png',dpi=300); print('slope',round(beta[1],4))
