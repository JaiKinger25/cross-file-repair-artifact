"""Commit-level pipeline: from git histories to the repository-level table (table_d1.csv).

REIMPLEMENTATION NOTICE
This script reimplements the procedure described in Sections 3-4 of the paper and in
Online Appendix A6. It is not the original script that produced the published table.
Before relying on it, run it on the 77 repositories and compare its output with
table_d1.csv; report any differences. Choices that the paper does not pin down
exactly (source-file extensions, test-path patterns, automation-account list) are
marked "ASSUMPTION" below and should be replaced with the original settings if known.

Steps
  1. clone      blob-less clones of the repositories listed in repositories.csv
  2. extract    every non-merge commit since 2024-01-01 (hash, author, committer, date,
                message, changed paths; renames not detected)
  3. mark       apply the AI-assistance marker rules (marker_rules.md)
  4. match      eligibility, sampling (at most 300 marked per repository) and matching
                (same repository, within 30 days, same file-count bin, same tests flag,
                up to five controls drawn without replacement; seed 20261020)
  5. outcomes   R14 (primary), placebo R14 before the commit, F14, RW14, REV30, W
  6. aggregate  repository-level table; repositories with fewer than 20 matched sets dropped

Usage
  python pipeline.py clone     --repos repositories.csv --dir clones
  python pipeline.py extract   --dir clones --out commits.jsonl
  python pipeline.py run       --commits commits.jsonl --out-sets matched_sets.csv --out-table table_d1_rebuilt.csv
Requires git on the PATH; cloning needs network access.
"""
import argparse, bisect, json, os, re, subprocess
from collections import defaultdict
from datetime import datetime, timedelta, timezone
import numpy as np
import pandas as pd

SINCE = "2024-01-01"
WINDOW_START = datetime(2024, 2, 1, tzinfo=timezone.utc)
SEED = 20261020
MAX_MARKED_PER_REPO = 300
MAX_CONTROLS = 5
MATCH_DAYS = 30
FOLLOW_DAYS = 14
REVERT_DAYS = 30
MIN_SETS = 20
FILE_BINS = [(1, 1), (2, 3), (4, 7), (8, 15), (16, 50)]

# ASSUMPTION: source-file extensions (the paper says "at least one a source file").
SOURCE_EXT = {".py", ".pyi", ".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx", ".go", ".rs", ".java", ".kt",
              ".scala", ".c", ".h", ".cc", ".cpp", ".hpp", ".cs", ".fs", ".rb", ".php", ".swift", ".m",
              ".mm", ".svelte", ".vue", ".lua", ".zig", ".dart", ".sh", ".ps1", ".sql", ".r", ".jl"}
# ASSUMPTION: a path counts as a test if it matches one of these patterns.
TEST_RE = re.compile(r"(^|/)(tests?|__tests__|spec|specs|testing)(/|$)|(^|/)test_[^/]+$|_test\.[a-z]+$|\.(test|spec)\.[a-z]+$",
                     re.IGNORECASE)
# ASSUMPTION: automation accounts (excluded as authors, except the Copilot and Devin agents).
BOT_RE = re.compile(r"\[bot\]|dependabot|renovate|github-actions|semantic-release|release-please|"
                    r"greenkeeper|snyk-bot|web-flow|pre-commit-ci|mergify|allcontributors", re.IGNORECASE)

FIX_RE = re.compile(r"\b(fix|bug|hotfix|regression|revert|broke|crash)\b", re.IGNORECASE)
REVERT_RE = re.compile(r"This reverts commit ([0-9a-f]{7,40})", re.IGNORECASE)

# AI-assistance marker rules (marker_rules.md); checked in this order.
def _line(pattern):
    return re.compile(r"^[^\w\n]{0,4}" + pattern, re.IGNORECASE | re.MULTILINE)

MARKERS = [
    ("Aider", None, re.compile(r"\(aider\)", re.IGNORECASE), re.compile(r"\Aaider:", re.IGNORECASE)),
    ("Claude Code", [_line(r"Co-authored-by:\s*Claude"), _line(r"Generated with \[?Claude Code")], None, None),
    ("Copilot", [_line(r"Co-authored-by:\s*(GitHub )?Copilot")], re.compile(r"copilot-swe-agent|Copilot <", re.IGNORECASE), None),
    ("Cursor", [_line(r"Co-authored-by:\s*Cursor Agent")], re.compile(r"cursoragent@cursor\.com", re.IGNORECASE), None),
    ("Codex", [_line(r"Co-authored-by:\s*Codex"), _line(r"generated with \[?Codex")], None, None),
    ("Devin", [_line(r"Co-authored-by:\s*Devin")], re.compile(r"devin-ai-integration", re.IGNORECASE), None),
    ("OpenHands", [_line(r"Co-authored-by:\s*OpenHands")], None, None),
]
AGENT_IDENTITY_RE = re.compile(r"copilot-swe-agent|Copilot <|devin-ai-integration", re.IGNORECASE)


def mark(c):
    """Return the tool family of an AI-marked commit, or None."""
    ident = f"{c['an']} <{c['ae']}> {c['cn']} <{c['ce']}>"
    msg = c["msg"]
    for family, msg_res, ident_re, prefix_re in MARKERS:
        if family == "Aider":
            if ident_re.search(c["an"]) or ident_re.search(c["cn"]) or prefix_re.search(msg):
                return family
            continue
        if msg_res and any(r.search(msg) for r in msg_res):
            return family
        if ident_re is not None and ident_re.search(ident):
            return family
    return None


def is_bot(c):
    ident = f"{c['an']} <{c['ae']}>"
    return bool(BOT_RE.search(ident)) and not AGENT_IDENTITY_RE.search(ident)


# ---------------------------------------------------------------- 1. clone
def cmd_clone(a):
    repos = pd.read_csv(a.repos).repository.tolist()
    os.makedirs(a.dir, exist_ok=True)
    for r in repos:
        dest = os.path.join(a.dir, r.replace("/", "__"))
        if os.path.exists(dest):
            continue
        print("cloning", r, flush=True)
        subprocess.run(["git", "clone", "--filter=blob:none", "--no-checkout", "--quiet",
                        f"https://github.com/{r}.git", dest], check=False)


# ---------------------------------------------------------------- 2. extract
SEP_C, SEP_F = "\x1e", "\x1f"

def extract_repo(path, repo):
    fmt = SEP_C + SEP_F.join(["%H", "%an", "%ae", "%cn", "%ce", "%cI", "%B"]) + SEP_F
    out = subprocess.run(["git", "-C", path, "log", "--all", "--no-merges", f"--since={SINCE}",
                          "--no-renames", "--name-only", f"--pretty=format:{fmt}"],
                         capture_output=True, text=True, errors="replace", check=True).stdout
    for block in out.split(SEP_C)[1:]:
        parts = block.split(SEP_F)
        h, an, ae, cn, ce, date, msg = parts[:7]
        files = [f for f in parts[7].strip().split("\n") if f.strip()] if len(parts) > 7 else []
        yield dict(repo=repo, h=h, an=an, ae=ae, cn=cn, ce=ce, date=date, msg=msg.strip(), files=files)


def cmd_extract(a):
    n = 0
    with open(a.out, "w") as fh:
        for d in sorted(os.listdir(a.dir)):
            repo = d.replace("__", "/")
            seen = set()
            for c in extract_repo(os.path.join(a.dir, d), repo):
                if c["h"] in seen:
                    continue
                seen.add(c["h"])
                fh.write(json.dumps(c) + "\n"); n += 1
    print(f"{n} commits written to {a.out}")


# ---------------------------------------------------------------- 3-6. mark, match, outcomes, aggregate
def file_bin(k):
    for i, (lo, hi) in enumerate(FILE_BINS):
        if lo <= k <= hi:
            return i
    return None


def outcomes(c, follow, times, reverts):
    """Outcomes for commit c. follow: non-bot commits sorted by time; times: their timestamps."""
    F = set(c["files"]); t = c["t"]
    r14 = f14 = rw14 = 0; width = 0
    lo = bisect.bisect_right(times, t); hi = bisect.bisect_right(times, t + timedelta(days=FOLLOW_DAYS))
    for x in follow[lo:hi]:
        G = set(x["files"])
        if F & G:
            rw14 = 1
            if x["fix"]:
                f14 = 1
                outside = len(G - F)
                if outside:
                    r14 = 1; width = max(width, outside)
    plac = 0                                   # placebo: the same event in the 14 days before c
    lo = bisect.bisect_left(times, t - timedelta(days=FOLLOW_DAYS)); hi = bisect.bisect_left(times, t)
    for x in follow[lo:hi]:
        G = set(x["files"])
        if x["fix"] and F & G and G - F:
            plac = 1; break
    rev = 0
    for full, tt in reverts.get(c["h"][:7], []):
        if c["h"].startswith(full) and timedelta(0) < tt - t <= timedelta(days=REVERT_DAYS):
            rev = 1
    return dict(R14=r14, F14=f14, RW14=rw14, W=width, REV30=rev, PLAC=plac)


def cmd_run(a):
    rng = np.random.default_rng(SEED)
    commits = [json.loads(l) for l in open(a.commits)]
    for c in commits:
        c["t"] = datetime.fromisoformat(c["date"]).astimezone(timezone.utc)
        c["family"] = mark(c)
        c["bot"] = is_bot(c)
        c["fix"] = bool(FIX_RE.search(c["msg"].split("\n", 1)[0]))
        c["tests"] = any(TEST_RE.search(f) for f in c["files"])
        c["bin"] = file_bin(len(c["files"]))
        c["source"] = any(os.path.splitext(f)[1].lower() in SOURCE_EXT for f in c["files"])
    by_repo = defaultdict(list)
    for c in commits:
        by_repo[c["repo"]].append(c)
    rows, sets_out = [], []
    for repo in sorted(by_repo):
        cs = sorted(by_repo[repo], key=lambda c: c["t"])
        last = cs[-1]["t"]
        window_end = last - timedelta(days=30)
        follow = [c for c in cs if not c["bot"]]                 # follow-ups by non-bot authors
        times = [c["t"] for c in follow]
        reverts = defaultdict(list)                              # reverted hash prefix -> revert times
        for c in cs:
            for m in REVERT_RE.finditer(c["msg"]):
                reverts[m.group(1)[:7]].append((m.group(1), c["t"]))
        elig = [c for c in cs if not c["bot"] and c["bin"] is not None and c["source"]
                and WINDOW_START <= c["t"] <= window_end]
        marked = [c for c in elig if c["family"]]
        unmarked = [c for c in elig if not c["family"]]
        if not marked:
            continue
        if len(marked) > MAX_MARKED_PER_REPO:
            idx = rng.choice(len(marked), MAX_MARKED_PER_REPO, replace=False)
            marked = [marked[i] for i in sorted(idx)]
        pool = defaultdict(list)
        for c in unmarked:
            pool[(c["bin"], c["tests"])].append(c)
        n_sets = 0; diffs = []; pm = []; pc = []
        for m in marked:
            cand = [c for c in pool[(m["bin"], m["tests"])] if abs(c["t"] - m["t"]) <= timedelta(days=MATCH_DAYS)]
            if not cand:
                continue
            k = min(MAX_CONTROLS, len(cand))
            ctrl = [cand[i] for i in rng.choice(len(cand), k, replace=False)]
            om = outcomes(m, follow, times, reverts)
            oc = [outcomes(c, follow, times, reverts) for c in ctrl]
            row = dict(repo=repo, marked=m["h"], family=m["family"], controls=";".join(c["h"] for c in ctrl), n_controls=k)
            for key in ["R14", "F14", "RW14", "W", "REV30", "PLAC"]:
                row[f"{key}_marked"] = om[key]
                row[f"{key}_control"] = float(np.mean([o[key] for o in oc]))
            sets_out.append(row)
            n_sets += 1; pm.append(om["R14"]); pc.append(row["R14_control"])
        if n_sets >= MIN_SETS:
            mr, cr = 100 * np.mean(pm), 100 * np.mean(pc)
            rows.append(dict(repo=repo, n=n_sets, marked=round(mr, 1), control=round(cr, 1), diff=round(mr - cr, 1)))
    pd.DataFrame(sets_out).to_csv(a.out_sets, index=False)
    t = pd.DataFrame(rows).sort_values("n", ascending=False)
    t.to_csv(a.out_table, index=False)
    print(f"{len(sets_out)} matched sets; {len(t)} repositories with at least {MIN_SETS} sets written to {a.out_table}")
    if len(t):
        th = (t.n * t["diff"]).sum() / t.n.sum()
        print(f"set-weighted difference in R14: {th:+.2f} pp")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("clone"); p.add_argument("--repos", default="repositories.csv"); p.add_argument("--dir", default="clones")
    p = sub.add_parser("extract"); p.add_argument("--dir", default="clones"); p.add_argument("--out", default="commits.jsonl")
    p = sub.add_parser("run"); p.add_argument("--commits", default="commits.jsonl")
    p.add_argument("--out-sets", default="matched_sets.csv"); p.add_argument("--out-table", default="table_d1_rebuilt.csv")
    a = ap.parse_args()
    {"clone": cmd_clone, "extract": cmd_extract, "run": cmd_run}[a.cmd](a)


if __name__ == "__main__":
    main()
