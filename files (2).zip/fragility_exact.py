"""Exact cluster fragility indices for the primary estimate (Section 3.3, Section 5.2).
FI_sig: smallest number of repositories whose removal makes the CR1 lower 95% bound <= 0 (exhaustive, k <= 5).
FI_dir (set-weighted): closed form via the largest contributions n_r * d_r.
FI_dir (random effects, DerSimonian-Laird): exhaustive, k <= 6 if needed."""
import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import numpy as np, pandas as pd, itertools
from scipy import stats
d=pd.read_csv(DATA); n=d.n.values.astype(float); y=d['diff'].values; G=len(d)
pm=d.marked.values/100; pc=d.control.values/100; v=(pm*(1-pm)/n+pc*(1-pc)/(4.8*n))*1e4
tq=np.array([0,0]+[stats.t.ppf(.975,g-1) for g in range(2,G+1)])
def lb(X):
    keep=1-X; g=keep.sum(1); W=keep*n; th=(W*y).sum(1)/W.sum(1)
    se=np.sqrt((g/(g-1))*((W*(y-th[:,None]))**2).sum(1))/W.sum(1); return th-tq[g]*se
def re_est(X):
    keep=(1-X).astype(float); g=keep.sum(1); wi=keep/v; fe=(wi*y).sum(1)/wi.sum(1)
    Q=(wi*(y-fe[:,None])**2).sum(1); C=wi.sum(1)-(wi**2).sum(1)/wi.sum(1); t2=np.maximum(0,(Q-(g-1))/C)
    ws=keep/(v+t2[:,None]); return (ws*y).sum(1)/ws.sum(1)
def exact_min(f,k):
    best=np.inf; arg=None; it=itertools.combinations(range(G),k)
    while True:
        ch=np.array(list(itertools.islice(it,200000)))
        if len(ch)==0: return best,arg
        X=np.zeros((len(ch),G),int); np.put_along_axis(X,ch,1,1); F=f(X); i=F.argmin()
        if F[i]<best: best=F[i]; arg=[d.repo[j] for j in ch[i]]
print('CR1 lower bound, no removal:', round(lb(np.zeros((1,G),int))[0],3))
for k in range(1,4):
    b,a=exact_min(lb,k); print(f'FI_sig search k={k}: min lower bound {b:.3f} removing {a}')
    if b<=0: print('FI_sig =',k); break
c=np.sort(n*y)[::-1]; print('FI_dir (set-weighted, exact) =', int(np.argmax(np.cumsum(c)>=(n*y).sum()))+1)
for k in range(1,7):
    b,a=exact_min(re_est,k); print(f'RE estimate k={k}: min {b:.3f} removing {a}')
    if b<=0: print('FI_dir (random effects) =',k); break
