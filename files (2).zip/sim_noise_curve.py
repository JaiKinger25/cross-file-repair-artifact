"""General result: bias and false-positive rate of the matched estimator under differential
proxy noise, as a function of the gap dq = q_M - q_C, compared with the closed form
bias ~= dq * (1 - pbar_obs0), where pbar_obs0 is the set-weighted observed control rate without noise
... (derivation: P_obs = 1-(1-p)(1-q) => d P_obs / d q = 1-p).
Also scenario S6: noise gap only in the post period (time-varying), where DiD is biased."""
import numpy as np, json, sys
import simulation as S
from scipy import stats
r=np.random.default_rng(int(sys.argv[2]))
dq=float(sys.argv[1]); post_only=len(sys.argv)>3
R=400; qC=0.30
th=[];did=[];rej=[];rejd=[]
for it in range(R):
    m=r.choice([5,4,3,2,1],S.S,p=[.85,.10,.03,.01,.01]); u=r.normal(0,1,S.S); D=r.normal(0,6.2,S.G)/100
    out={}
    for per in ('pre','post'):
        qM=qC+dq/100 if (per=='post' or not post_only) else qC
        pc=S.expit(S.base[S.rid]+u); pm=np.clip(pc+(D[S.rid] if per=='post' else 0),0,1)
        ym=(r.random(S.S)<pm)|(r.random(S.S)<qM)
        yt=r.binomial(m,pc); yc=(yt+r.binomial(m-yt,qC))/m
        out[per]=np.bincount(S.rid,ym-yc)/S.n*100
    t,pct,_,cr,se=S.intervals(out['post'],r,B=299); th.append(t); rej.append(S.wild_reject(out['post'],0.0,r,B=199))
    dd=out['post']-out['pre']; td,_,_,crd,_=S.intervals(dd,r,B=99); did.append(td); rejd.append(S.wild_reject(dd,0.0,r,B=199))
pbar=(S.w*(1/(1+np.exp(-S.base)))).sum()
res=dict(dq=dq,post_only=post_only,bias=float(np.mean(th)),bias_did=float(np.mean(did)),fpr_wild=float(np.mean(rej)),fpr_did_wild=float(np.mean(rejd)),
         closed_form=float(dq*(1-pbar)*(1-qC)) if False else float(dq*(1-pbar)), sd=float(np.std(th)))
print(json.dumps(res)); json.dump(res,open(f'noise_{dq}_{int(post_only)}.json','w'))
