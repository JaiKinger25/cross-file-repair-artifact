"""Probabilistic quantitative bias analysis for outcome misclassification (R14 proxy)."""
import os as _os
DATA=next(p for p in ['table_d1.csv','../data/table_d1.csv'] if _os.path.exists(p))  # works flat or in data/
import numpy as np, pandas as pd, json
rng=np.random.default_rng(20261020)
d=pd.read_csv(DATA); n=d.n.values; pm=d.marked.values; pc=d.control.values; G=len(d)
M=200000
idx=rng.integers(0,G,(M,G))
PM=(n[idx]*pm[idx]).sum(1)/n[idx].sum(1); PC=(n[idx]*pc[idx]).sum(1)/n[idx].sum(1)
def beta_ms(mean,sd,size):
    v=sd**2; c=mean*(1-mean)/v-1; return rng.beta(mean*c,(1-mean)*c,size)
out={}
scen={
 'A_nondiff_exact':dict(ratio_mu=0.0,ratio_sd=0.0),
 'B_nondiff_noise5':dict(ratio_mu=0.0,ratio_sd=0.05),
 'C_nondiff_noise10':dict(ratio_mu=0.0,ratio_sd=0.10),
 'D_marked_lower5':dict(ratio_mu=np.log(0.95),ratio_sd=0.05),
}
for k,s in scen.items():
    p_c=beta_ms(0.5,0.15,M)
    rho=np.exp(rng.normal(s['ratio_mu'],s['ratio_sd'],M)) if s['ratio_sd']>0 else np.ones(M)*np.exp(s['ratio_mu'])
    p_m=np.clip(p_c*rho,0,1)
    se=rng.uniform(0.6,0.9,M)          # nondifferential sensitivity
    true=(PM*p_m-PC*p_c)/se
    out[k]=dict(median=float(np.median(true)),lo=float(np.percentile(true,2.5)),hi=float(np.percentile(true,97.5)),p_pos=float((true>0).mean()))
    print(k,out[k])
json.dump(out,open('bias_analysis.json','w'),indent=1)
