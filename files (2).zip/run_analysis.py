"""Reproduce the paper's results with one command.

  python run_analysis.py            repository-level analyses, figures and a quick simulation check (about 5 minutes)
  python run_analysis.py --full     also the full simulation study, 2,000 replicates per scenario (about 15-20 minutes)

Steps
  1. reanalysis.py       Table 2, prediction interval, meta-regression (Section 5.2)
  2. fragility_exact.py  fragility indices FI_sig = 2, FI_dir = 8 and 6 (Section 5.2)
  3. bias_analysis.py    probabilistic bias analysis (Section 7)
  4. analysis.py         Table 1 from matched_sets.csv, only if that file is present (produced by pipeline.py)
  5. simulation.py       Table 3 (scenarios Sim0-Sim5; named S0-S5 in the code)
  6. fig_metareg.py, fig_noise.py   Figures 1 and 2
All outputs are written to the results/ folder.
"""
import os, subprocess, sys, shutil

FULL = "--full" in sys.argv
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)


def run(label, args, outputs=()):
    print(f"\n=== {label} ===", flush=True)
    r = subprocess.run([sys.executable] + args, cwd=HERE)
    if r.returncode != 0:
        print(f"!! {label} failed (exit code {r.returncode})"); return
    for f in outputs:
        p = os.path.join(HERE, f)
        if os.path.exists(p):
            shutil.move(p, os.path.join(OUT, f))


run("Repository-level re-analysis (Table 2)", ["reanalysis.py"], ["reanalysis.json"])
run("Exact fragility indices", ["fragility_exact.py"])
run("Probabilistic bias analysis (Section 7)", ["bias_analysis.py"], ["bias_analysis.json"])
if os.path.exists(os.path.join(HERE, "matched_sets.csv")):
    run("Main analysis (Table 1)", ["analysis.py", "--sets", "matched_sets.csv", "--out", "table1_results.csv"], ["table1_results.csv"])
else:
    print("\n=== Main analysis (Table 1) skipped: matched_sets.csv not found (run pipeline.py first) ===")
reps = "2000" if FULL else "50"
for s in range(6):
    run(f"Simulation scenario Sim{s} ({reps} replicates)", ["simulation.py", reps, str(s)], [f"sim_{s}_{reps}_sdu1.0.json"])
run("Figure 1", ["fig_metareg.py"], ["fig2_metareg.png"])
run("Figure 2", ["fig_noise.py"], ["fig_noise.png"])
print(f"\nDone. Outputs are in {OUT}" + ("" if FULL else "\n(Quick simulation check only; use --full for Table 3.)"))
